package com.example.school_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DocumentsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DocumentsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    private static final String GradeIdText = "GradeId";
    private static final String GradeText = "Grade";
    private static final String GradeNoText = "GradeNo";
    private static final String SubjectText = "Subject";
    private static final String TeacherSSNText = "TeacherSSN";
    private static final String TeacherNameText = "TeacherName";



    private String GradeId ;
    private String Grade;
    private String GradeNo;
    private String Subject;
    private String TeacherSSN;
    private String TeacherName;
    Button uploadFilebtn;

    ArrayList<String> fileNames;
    ArrayList<String> fileUrls;

    RecyclerView myRecycler ;
    DatabaseReference myref ;
  private  FirebaseRecyclerOptions<FileModel> myOptions;
  private FirebaseRecyclerAdapter<FileModel,FileViewHolder> myAdapter;





    // TODO: Rename and change types and number of parameters
    // TODO: Rename and change types and number of parameters
    public static DocumentsFragment newInstance(String GradeId,String Grade , String GradeNo ,String Subject , String TeacherSSN,String TeacherName) {
        DocumentsFragment fragment = new DocumentsFragment();
        Bundle args = new Bundle();
        args.putString(GradeIdText, GradeId);
        args.putString(GradeText, Grade);
        args.putString(GradeNoText, GradeNo);
        args.putString(SubjectText, Subject);
        args.putString(TeacherSSNText, TeacherSSN);
        args.putString(TeacherNameText, TeacherName);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
          View v = inflater.inflate(R.layout.fragment_documents, container, false);
        if (getArguments() != null) {
            GradeId = getArguments().getString(GradeIdText);
            Grade =  getArguments().getString(GradeText);
            GradeNo =  getArguments().getString(GradeNoText);
            Subject = getArguments().getString(SubjectText);
            TeacherSSN =  getArguments().getString(TeacherSSNText);
            TeacherName = getArguments().getString(TeacherNameText);


        }

    uploadFilebtn= v.findViewById(R.id.uploadFileBtn);
        uploadFilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getActivity() , uploadFileActivity.class);
                myIntent.putExtra(GradeIdText,GradeId);
                myIntent.putExtra(TeacherSSNText,TeacherSSN);
                startActivity(myIntent);

            }
        });



        myref = FirebaseDatabase.getInstance().getReference().child("Classes").child(GradeId).child("Files");
        fileNames= new ArrayList<String>();
        fileUrls = new ArrayList<String>();

        myref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fileNames.clear();
                fileUrls.clear();
                for (DataSnapshot shot : snapshot.getChildren())
                {

                    //System.out.println("haha  , " +shot.child("fileName").getValue() + " URL : "+ shot.child("fileUril").getValue());
                   String s=shot.child("fileName").getValue().toString();
                   fileNames.add(s);
                   fileUrls.add(shot.child("fileUril").getValue().toString());

                }

                ListView myFilesList=v.findViewById(R.id.filesList);
                ArrayList<Listtitem1>listB=new ArrayList<Listtitem1>();
                for (int i=0;i<fileNames.size();i++){

                    listB.add(new Listtitem1(fileNames.get(i),R.drawable.deleteitem));

                }
                listAdapter ll=new listAdapter(listB);
                myFilesList.setAdapter(ll);

                myFilesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                       String urlItem = fileUrls.get(position);
                       Uri myUrl = Uri.parse(urlItem);
                       startActivity(new Intent(Intent.ACTION_VIEW,myUrl));
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return v;


    }

    class listAdapter extends BaseAdapter{
       ArrayList<Listtitem1> ListItem=new ArrayList<Listtitem1>();
       listAdapter(ArrayList<Listtitem1> list){
           ListItem=list;
       }

        @Override
        public int getCount() {
            return ListItem.size();
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public Object getItem(int position) {
            return ListItem.get(position).text;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
           LayoutInflater layoutInflater=getLayoutInflater();
           View view=layoutInflater.inflate(R.layout.list_item1,null);
           TextView textView=view.findViewById(R.id.TextViewNameItem);
            ImageView imageView=view.findViewById(R.id.ImageViewItem);

            textView.setText(ListItem.get(position).text);
            imageView.setImageResource(ListItem.get(position).image);

           final int click=position;
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    System.out.println(click);

                }
            });



            return view;
        }
    }




}