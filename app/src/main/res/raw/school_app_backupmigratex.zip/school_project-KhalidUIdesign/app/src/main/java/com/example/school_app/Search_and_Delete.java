package com.example.school_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Search_and_Delete extends AppCompatActivity {



    private String type_click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_and__delete);

        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }


        Intent intent=getIntent();
        type_click=intent.getStringExtra("nametype");

        TextView textView=findViewById(R.id.text_click);
          textView.setText(type_click);

        if(type_click.equals("Search")){
            LinearLayout l=findViewById(R.id.search_liner);
            l.setVisibility(View.VISIBLE);

        }else {

            LinearLayout l=findViewById(R.id.delete_liner);
            l.setVisibility(View.VISIBLE);

        }






    }

    public void image_button(View view) {



    }

    public void delete_button(View view) {

    }
}