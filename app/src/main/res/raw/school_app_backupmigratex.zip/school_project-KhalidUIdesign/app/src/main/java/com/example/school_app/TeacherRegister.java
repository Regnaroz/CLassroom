package com.example.school_app;

public class TeacherRegister {

    private String _TeacherName;
    private String _TeacherPassword;
    private String _TeacherSSN;
    private String _TeacherPhone;
    //private String _TeacherSubject;

    public TeacherRegister() {

    }

    public String get_TeacherName() {
        return _TeacherName;
    }

    public void set_TeacherName(String _TeacherName) {
        this._TeacherName = _TeacherName;
    }

    public String get_TeacherPassword() {
        return _TeacherPassword;
    }

    public void set_TeacherPassword(String _TeacherPassword) {
        this._TeacherPassword = _TeacherPassword;
    }

    public String get_TeacherSSN() {
        return _TeacherSSN;
    }

    public void set_TeacherSSN(String _TeacherSSN) {
        this._TeacherSSN = _TeacherSSN;
    }

    public String get_TeacherPhone() {
        return _TeacherPhone;
    }

    public void set_TeacherPhone(String _TeacherPhone) {
        this._TeacherPhone = _TeacherPhone;
    }


}
