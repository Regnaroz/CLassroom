package com.example.school_app;

public class AdminRegister {

    private String _AdminName;
    private String _AdminPassword;
    private String _AdminSSN;
    private String _AdminPhone;
    private String _AddPermession;

    public AdminRegister() {
    }

    public String get_AdminName() {
        return _AdminName;
    }

    public void set_AdminName(String _AdminName) {
        this._AdminName = _AdminName;
    }

    public String get_AdminPassword() {
        return _AdminPassword;
    }

    public void set_AdminPassword(String _AdminPassword) {
        this._AdminPassword = _AdminPassword;
    }

    public String get_AdminSSN() {
        return _AdminSSN;
    }

    public void set_AdminSSN(String _AdminSSN) {
        this._AdminSSN = _AdminSSN;
    }

    public String get_AdminPhone() {
        return _AdminPhone;
    }

    public void set_AdminPhone(String _AdminPhone) {
        this._AdminPhone = _AdminPhone;
    }

    public String get_AddPermession() {
        return _AddPermession;
    }

    public void set_AddPermession(String _AddPermession) {
        this._AddPermession = _AddPermession;
    }
}
