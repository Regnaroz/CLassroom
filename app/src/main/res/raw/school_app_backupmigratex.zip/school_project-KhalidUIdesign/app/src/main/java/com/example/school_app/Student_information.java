package com.example.school_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import cn.pedant.SweetAlert.SweetAlertDialog;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class Student_information extends AppCompatActivity {


    private String student_ssn;
    private VideoView background_student_information;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_information);

        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }






        Intent intent=getIntent();
        student_ssn=intent.getStringExtra("ssn");

          // change password button
        CardView c=findViewById(R.id.save_pass_card_view);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText current_password=findViewById(R.id.edit_text_current_password);
                EditText new_password=findViewById(R.id. edit_text_new_password);
                EditText confirm_new_password=findViewById(R.id.edit_confirm_new_password);
                if(current_password.getText().toString().equals("")&& new_password.getText().toString().equals("")&&confirm_new_password.getText().toString().equals(""))
                {
                    new SweetAlertDialog(Student_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("Password information is Empty!").show();

                }else if(current_password.getText().toString().equals("")){

                    new SweetAlertDialog(Student_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the current password is Empty!").show();


                }else if(new_password.getText().toString().equals("")){

                    new SweetAlertDialog(Student_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the new password is Empty!").show();

                }else if(confirm_new_password.getText().toString().equals("")){
                    new SweetAlertDialog(Student_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the confirm new password is Empty").show();

                }else if(new_password.getText().toString().equals(confirm_new_password.getText().toString())){
                    Toast.makeText(Student_information.this,"done",Toast.LENGTH_SHORT).show();

                    //Write the code here


                }else {
                    new SweetAlertDialog(Student_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("Password does not match").show();


                }
            }
        });





    }
}