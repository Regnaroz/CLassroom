package com.example.school_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import cn.pedant.SweetAlert.SweetAlertDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Admin_information extends AppCompatActivity {


    private String admin_ssn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_information);
        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }

        Intent intent=getIntent();
        admin_ssn=intent.getStringExtra("ssn");

        // change password button
        CardView c=findViewById(R.id.save_admin_pass_card_view);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText current_password=findViewById(R.id.admin_edit_text_current_password);
                EditText new_password=findViewById(R.id.admin_edit_text_new_password);
                EditText confirm_new_password=findViewById(R.id.admin_edit_confirm_new_password);
                if(current_password.getText().toString().equals("")&& new_password.getText().toString().equals("")&&confirm_new_password.getText().toString().equals(""))
                {
                    new SweetAlertDialog(Admin_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("Password information is Empty!").show();

                }else if(current_password.getText().toString().equals("")){

                    new SweetAlertDialog(Admin_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the current password is Empty!").show();


                }else if(new_password.getText().toString().equals("")){

                    new SweetAlertDialog(Admin_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the new password is Empty!").show();

                }else if(confirm_new_password.getText().toString().equals("")){
                    new SweetAlertDialog(Admin_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("the confirm new password is Empty").show();

                }else if(new_password.getText().toString().equals(confirm_new_password.getText().toString())){
                    Toast.makeText(Admin_information.this,"done",Toast.LENGTH_SHORT).show();

                    //Write the code here


                }else {
                    new SweetAlertDialog(Admin_information.this, SweetAlertDialog.ERROR_TYPE).setTitleText("Password does not match").show();


                }
            }
        });



    }
}