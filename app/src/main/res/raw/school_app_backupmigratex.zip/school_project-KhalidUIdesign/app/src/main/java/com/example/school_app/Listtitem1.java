package com.example.school_app;

public class Listtitem1 {

    public String text;
    public  int image;

    public Listtitem1(String text, int image) {
        this.text = text;
        this.image = image;
    }
}
