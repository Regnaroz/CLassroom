package com.example.school_app;

public class StudentRegister {

    private String _StudentName;
    private String _StudentPassword;
    private String _StudentSSN;
    private String _StudentPhone;
    private String _Parentname;
    private String _ParentSSN;
    private String _ParentPhone;



    public StudentRegister() {


    }

    public String get_StudentPassword() {
        return _StudentPassword;
    }

    public void set_StudentPassword(String _StudentPassword) {
        this._StudentPassword = _StudentPassword;
    }




    public String get_StudentName() {
        return _StudentName;
    }

    public void set_StudentName(String _StudentName) {
        this._StudentName = _StudentName;
    }

    public String get_StudentPhone() {
        return _StudentPhone;
    }

    public void set_StudentPhone(String _StudentPhone) {
        this._StudentPhone = _StudentPhone;
    }

    public String get_Parentname() {
        return _Parentname;
    }

    public void set_Parentname(String _Parentname) {
        this._Parentname = _Parentname;
    }

    public String get_ParentSSN() {
        return _ParentSSN;
    }

    public void set_ParentSSN(String _ParentSSN) {
        this._ParentSSN = _ParentSSN;
    }

    public String get_ParentPhone() {
        return _ParentPhone;
    }

    public void set_ParentPhone(String _ParentPhone) {
        this._ParentPhone = _ParentPhone;
    }

    public String get_StudentSSN() {
        return _StudentSSN;
    }

    public void set_StudentSSN(String _StudentSSN) {
        this._StudentSSN = _StudentSSN;
    }


}
